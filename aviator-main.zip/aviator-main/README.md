<h3 align=center>
<img src='https://i.ibb.co/Y72Yyfr/Picsart-24-05-04-22-40-56-935.jpg'>
</h3>
<h3 align=center>
<table align=center> <tr>
      <th scope="col">Aviator Prediction App</th>
      <th scope="col">06 / 05 / 2024</th>
  <th scope="col"><a href='https://b120s.github.io/aviator'>Download</th>
 </tr><table/>
<h4 align=center>Available for Windows, iOS, and Android
